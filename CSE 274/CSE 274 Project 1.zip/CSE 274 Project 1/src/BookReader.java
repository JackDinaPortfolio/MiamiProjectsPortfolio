/*
 * @author Jack Dina
 * 
 * CSE 274 Section B
 * Date 9/6/2022
 * 
 * This program gets the top ten words from text files in a folder,
 * and it prints the runtime that it takes to go through this folder.
 */

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class BookReader {
	
	//Variables that will be used later.
	private static double BEGINNINGTIME = System.currentTimeMillis();
	private static String folderName = "";
	private static Scanner filescanner;
	private static Scanner in  = new Scanner(System.in);
	static ArrayList<Word> Words = new ArrayList<Word>();
	
	//Main method that runs all methods.
	public static void main(String[] args) throws FileNotFoundException {
		
		//Prints beginning message, and gets folder.
		System.out.println("Please enter directory name ");
		folderName = in.next();
		System.out.println("");
		
		//runs the main command.
		File folder = new File(folderName);
		folderContents(folder);
		
		//Gets the total runtime of the program and prints it to the screen.
		double ENDTIME = System.currentTimeMillis();
		System.out.println("Time taken: " + (ENDTIME - BEGINNINGTIME) + " ms");
		
	}
	
	//Examines folder contents and gets the data from them.
	//Also manipulates the data.
	private static void folderContents(File folder) throws FileNotFoundException {
		System.out.println("The files are:");
		for (File contents : folder.listFiles()) {
			System.out.println(contents.getName());
		}
		System.out.println("");
	    for (File contents : folder.listFiles()) {
	    	filescanner = new Scanner (new File(folder + "/" +  contents.getName())).useDelimiter("[^a-zA-Z]+");
	    	
	    	//Goes through every word in the file and sees if they need to be 
	    	//added to the arrayList or if they need to increase a counter.
	    	//Also should remove the words "the", "and", "an", and "a"
	    	while(filescanner.hasNext()) {
	    		boolean wordNeedsAdd = true;
	    		String word = filescanner.next().toLowerCase();
				Word newWord = new Word(word);
				
				//Should remove the words.
				if ((word.equals("the")) || (word.equals("a")) || (word.equals("an")) || (word.equals("and"))){
					continue;
				}
				
				//Adds the first word to the arrayList so that it can begin properly.
				if(Words.size() == 0) {
					Words.add(newWord);
				}
				
				//Checks the arrayList to see if the word is already in it, and if it is
				//it increases the word counter and breaks the array.
				for(int i = 0; i < Words.size(); i++) {
					if(Words.get(i).getWordName().matches(word)) {
						Words.get(i).repeatWord();
						wordNeedsAdd = false;
						break;
					}
				}
				
				//If the word counter didn't get increased it adds a new word.
				if (wordNeedsAdd == true) {
					Words.add(newWord);
				}
			}
	    	
	    	//Gets the top 10 most used words.
	    	ArrayList<Word> topTen = new ArrayList<Word>();
	    	int listSize = Words.size();
	    	for (int j = 0; j < 10; j++) {
	    		int max = Words.get(0).getWordCounter();
	    		int iKeeper = 0;
	    		for(int i = 0; i < Words.size(); i++) {
	    			if (max < Words.get(i).getWordCounter()) {
	    				max = Words.get(i).getWordCounter();
	    				iKeeper = i;
	    			}
	    		}
	    		topTen.add(Words.get(iKeeper));
	    		Words.remove(iKeeper);
	    	} 
	    	
	    	//Prints the end statement.
	    	System.out.println("The total number of words in " + contents.getName() + " is: " + listSize);
	    	System.out.println("The top ten words in " + contents.getName());
	    	for (int i = 9; i >= 0; i--) {
	    		System.out.println (topTen.get(i).getWordName() + " , " + topTen.get(i).getWordCounter());
	    	}
	    	System.out.println("");
	    	
	    	//Clears the words from the list so that the next file has an empty array
	    	//to work with.
	    	Words.clear();
	    	
	    	
	    }
	    
	}
	
}
