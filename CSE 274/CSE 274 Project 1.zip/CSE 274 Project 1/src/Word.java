/*
 * @author Jack Dina
 * 
 * CSE 274 Section B
 * Date 9/6/2022
 * 
 * This object class is meant to work with BookReader.java to 
 * help make things simpler.
 */

public class Word {

	//Variables needed for the code.
	int counter = 1;
	String wordName = "";
	
	//Constructor that creates the word object.
	public Word (String wordName) {
		this.wordName = wordName;
	}
	
	//Increases the counter if the word appears again.
	public void repeatWord() {
		counter += 1;
	}
	
	//Returns the number of times the word appears. 
	public int getWordCounter() {
		return counter;
	}
	
	//Returns the name of the word.
	public String getWordName() {
		return wordName;
	}
}
